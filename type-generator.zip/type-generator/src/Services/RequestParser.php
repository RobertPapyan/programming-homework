<?php

namespace Matemat\TypeGenerator\Services;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Validation\Rule;
use Matemat\TypeGenerator\Interfaces\FileParser;
use Matemat\TypeGenerator\Models\MigrationModel;
use Symfony\Component\Finder\SplFileInfo;

class RequestParser implements FileParser
{
    private array $rullesMap = [
        'accepted' => [
            'field_type' => 'concrete',
            'field_values' => ['yes','on',1,'1',true,"true"]
        ],
        'active_url'=>['field_type' => 'string'],
        'alpha' => ['field_type' => 'string'],
        'alpha_dash' => ['field_type' => 'string'],
        'alpha_num' => ['field_type' => 'string'],
        'array' => ['field_type' => 'array'],
        'boolean' => ['field_type' => 'boolean'],
        'contains' => ['field_type' => 'array'],
        'current_password' => ['field_type' => 'string'],
        'date' => ['field_type' => 'string'],
        'date_equals' => ['field_type' => 'string'],
        'decimal' => ['field_type' => 'number'],
        'declined' => [
            'field_type' => 'concrete',
            'field_values' => ['no','off',0,'0',false,"false"]
        ],
        'digits' => ['field_type' => 'number'],
        'digits_between' => ['field_type' => 'number'],
        'email' => ['field_type' => 'string'],
        'enum' => ['field_type' => 'string'],
        'file' => ['field_type' => 'file'],
        'hex_color'=>['field_type' => 'string'],
        'image' => ['field_type' => 'file'],
        'integer' => ['field_type' => 'number'],
        'ip' => ['field_type' => 'string'],
        'ipv4' => ['field_type' => 'string'],
        'ipv6' => ['field_type' => 'string'],
        'json' => ['field_type' => 'string'],
        'list' => ['field_type' => 'array'],
        'mac_address' => ['field_type' => 'string'],
        'mimetypes' => ['field_type' => 'file'],
        'mimes' => ['field_type' => 'file'],
        'numeric' => ['field_type' => 'number'],
        'string' => ['field_type' => 'string'],
        'timezone' => ['field_type' => 'string'],
        'url' => ['field_type' => 'string'],
        'uuid' => ['field_type' => 'string'],
        'ulid' => ['field_type' => 'string'],
    ];
    public  function __construct()
    {

    }
    public  function parse(SplFileInfo $file):array{
        $models = [];
        $content = $file->getContents();
        $modelName = $this->getName($content);
        if($modelName){
            $requestType = $this->getType($modelName);
            $fields = $this->getFields($content,$modelName);
            $fields = $this->normalizeFields($fields);
            $model = new MigrationModel($modelName,$requestType);
            foreach ($fields as $fieldName => $rules){
                $this->handleField($fieldName,$rules,$model);
            }

           $models[] = $model;
        }

        return $models;
    }


    private function getName(string $content):string|null{
        if(preg_match('/(?<=\bclass\s)\w+(?=\s+extends)/', $content,$matches)){
            return trim($matches[0]);
        }
        return null;
    }
    private function getType(string $name):string|null{
        if(str_contains($name,'Update')){
            return 'update';
        }
        if(str_contains($name,'Store')){
            return 'store';
        }
        return null;
    }

    private function getFields(string $content,string $name):array{

        if(preg_match('/rules\(\)\s*.*?(return\s*\[\s*.*?\]\s*;)/s',$content,$matches)){

            $rules = $matches[1];
            $rules = $this->removeUnnecesarryBrackets($rules);
            //$rules = $this->addCommasBeforeSquareBrackets($rules);

            //Remove Rule:: statements
            $rules = preg_replace('/Rule::\w+\(.*?\)(?:->.*?)*?(?=\s*,|\s*\]|\s*$)/', "''", $rules);
            $rules = preg_replace('/Rule::.*?\)\s*(?:\n|,)/s', "'',", $rules);
            $rules = preg_replace('~new[^,\]]*(?=[,\]])~', "''", $rules);
            $rules = preg_replace('/\$(.*?)(?=[,\]])/', "''", $rules);
            //var_dump($content);
            try {
                $result = eval($rules);
                if (is_array($result)) {
                    return $result;
                }
            } catch (\Throwable $e) {
                dd($content);
                var_dump("Cannot parse FormRequest file:".$name);
                var_dump($e->getMessage());
            }
        }

        return [];
    }
    private function removeUnnecesarryBrackets(string $rules):string{

        $allowedValues = ["'",",",'.',"=",">","[","]",'"', ' ', "\n"];
        $first = false;
        $started = false;
        $start = 0;

        for ($i = 0; $i<strlen($rules); $i++) {
            if($first){
                if(!in_array($rules[$i],$allowedValues) && isset($rules[$i+1]) && $rules[$i+1] == '['){
                    $started = true;
                    $start = $i+1;
                }else{
                    if($started && $rules[$i] == ']'){
                        $rules = substr($rules, 0, $start) . substr($rules, $i+1);
                        $started = false;
                    }
                }

            }

            if($rules[$i] == '[') {
                $first = true;
            }
        }
        return $rules;
    }
    private function addCommasBeforeSquareBrackets(string $rules): string{
        $alreadyPlaced = false;
        $seek = false;

        for($i = strlen($rules) - 1; $i >= 0; $i--){
            if($rules[$i] == ' ')continue;
            if($rules[$i] == "\n" ){
                if($alreadyPlaced){$alreadyPlaced = false;}
                continue;
            }
            if($rules[$i] == ',' && $seek){
                $seek = false;
                $alreadyPlaced = true;
            }
            if($rules[$i] == ']' && !$alreadyPlaced){
                $seek = true;
                continue;
            }
            if($seek && $rules[$i] != ','){

               $rules = substr($rules, 0, $i+1) . ',' . substr($rules, $i+1);
               $alreadyPlaced = true;
               $seek = false;
            }

        }
        return $rules;
    }
    private function normalizeFields(array $rules):array{
        foreach ($rules as $name => $rule){
            if(is_string($rule)){
                $rules[$name] =  explode('|',$rule);
            }else{
                $rules[$name] = array_filter($rule,'is_string');
            }

        }
        return $rules;
    }
    private function handleField(string $fieldName ,array $rules,MigrationModel $model):void{
            $fieldTypeLock = false;
            $field = [
                'field_name' => $fieldName,
                'modifiers' => []
            ];

            //field can be already created via hierarchy builder function
            if($this->fieldExists($fieldName,$model)){
                foreach ($model->fields as $key => $field){
                    if(isset($field['field_slug']) && $field['field_slug'] === $fieldName){
                        foreach ($rules as $rule){
                            $ruleParts = explode(':',$rule);
                            $ruleName = $ruleParts[0];
                            if($ruleName == 'nullable') {
                                $model->fields[$key]['modifiers'][]  = 'nullable';
                            }
                        }
                    }
                }
                return;
            }


            //Handles nested arrays and objects
            if(str_contains($fieldName,'.')){
                $parts = explode('.',$fieldName);

               // if nested fieldname becomes slug and field name is the last part of slug
                $fieldSlug = $fieldName;
                $fieldName = $this->buildHierarchy($parts,$model,$parts[0]);
                $field['field_slug'] = $fieldSlug;
                $field['field_name'] = $fieldName;
                array_pop($parts);
                $field['parent'] = implode('.',array_filter($parts,function($part){
                    return $part !== '' && $part !== '*';
                }));
            }


            foreach ($rules as $rule){
                 $ruleParts = explode(':',$rule);
                 $ruleName = $ruleParts[0];
                 if(isset($this->rullesMap[$ruleName])){
                     $field =  array_merge($field,$this->rullesMap[$ruleName]);
                 }
                 if($ruleName == 'in'){
                     $field['field_type'] = 'concrete';
                     $field['field_values'] = explode(',',$ruleParts[1]);
                 }
                if($ruleName == 'nullable') {
                    $field['modifiers'][] = 'nullable';
                }
            }

            if(!isset($field['field_type'])){
                $field['field_type'] = 'any';
            }
            if($field['field_type'] == 'array' && !isset($field['field_slug'])){
                $field['field_slug'] = $field['field_name'];
            }
            $model->addField($field);
    }

    private function  buildHierarchy( array $members,MigrationModel $model, string $slug, string $parent = null )
    {
        $current = array_shift($members);

        if(empty($members))return $current;
        if($members[0] == ''){array_shift($members);}
        if($current !== '*' ){

            $isArray = $members[0] == '*';
            $field = [
                'field_name' => $current,
                'field_slug' => $slug,
                'field_type' => $isArray ? 'array' : 'object',
                'modifiers' => []
            ];
            if($parent){
                $field['parent'] = $parent;
                $parent = $members[0];
            }

            //skip if hierarchy member is already created
            if(!$this->fieldExists($slug,$model)){
                $model->addField($field);
            }else{

                //fix the issue where php treats objects as associative arrays
                if(!$isArray){
                    foreach ($model->fields as $key => $field){
                        if(isset($field['field_slug']) && $field['field_slug'] == $slug){
                            $model->fields[$key]['field_type'] = 'object';
                        }
                    }
                }
            }
        }
        $parent = $slug;
        $slug = $slug . '.' . $members[0];
        return $this->buildHierarchy($members,$model,$slug,$parent);
    }


    private function fieldExists(string $slug, MigrationModel $model):bool{
            foreach ($model->fields as $field){
                if(isset($field['field_slug'] )&& $field['field_slug'] == $slug){
                    return true;
                }
            }
            return false;
    }

}
